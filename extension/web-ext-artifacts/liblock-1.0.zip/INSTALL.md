# installing the extension

# Install manually

1. Open the extensions page by typing `chrome://extensions`.
2. Turn on "developer mode"
3. Download a zip file of this extension from one of these places:
	- [Github](https://github.com/bkf2020/liblock)
	- [Gitlab](https://gitlab.com/bkf2020/liblock)
	- [Codeberg](https://codeberg.org/bkf2020/liblock)
4. Unzip the zip file
5. Click "load unpacked extensions" on `chrome://extensions` and
   choose the folder containing the extension
