#!/bin/sh

git push
git push --prune https://gitlab.com/bkf2020/liblock.git
git push --prune https://codeberg.org/bkf2020/liblock.git
